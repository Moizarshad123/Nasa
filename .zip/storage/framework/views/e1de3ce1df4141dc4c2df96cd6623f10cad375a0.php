<!-- menu -->
<div class="menu">
    <div class="menu-header">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="menu-header-logo">
            <img src="<?php echo e(asset('admin/logo.jpg')); ?>" alt="logo" style="width: 200px">
        </a>
        <a href="<?php echo e(url('/')); ?>" class="btn btn-sm menu-close-btn">
            <i class="bi bi-x"></i>
        </a>
    </div>
    <div class="menu-body">
        <div class="dropdown">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="d-flex align-items-center" data-bs-toggle="dropdown">
                <div class="avatar me-3">
                    <img src="<?php echo e(asset('admin/assets/images/user/man_avatar3.jpg')); ?>"
                         class="rounded-circle" alt="image">
                </div>
                <div>
                    <div class="fw-bold">Nasa Studio</div>
                </div>
            </a>
            
        </div>
        <ul>
            <li>
                <a  class="<?php echo e(request()->IS('admin/dashboard') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.dashboard')); ?>">
                    <span class="nav-link-icon">
                        <i class="bi bi-bar-chart"></i>
                    </span>
                    <span>Dashboard</span>
                </a>
            </li>
            <li>
                <a class="<?php echo e(request()->IS('admin/orderBigDC') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.orderBigDC.index')); ?>">
                    <span class="nav-link-icon">
                        <i class="bi bi-person-badge"></i>
                    </span>
                    <span>Order Big DC</span>
                </a>
            </li>
         
            <li>
                <a class="<?php echo e(request()->IS('admin/orderSmallDC') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.orderSmallDC.index')); ?>">
                    <span class="nav-link-icon">
                        <i class="bi bi-receipt"></i>
                    </span>
                    <span>Order Small DC</span>
                </a>
            </li>

            <li>
                <a class="<?php echo e(request()->IS('admin/editing-department') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.editingDepartment')); ?>">
                    <span class="nav-link-icon">
                        <i class="bi bi-paperclip"></i>
                    </span>
                    <span>Editing Department</span>
                </a>
            </li>

            <li>
                <a class="<?php echo e(request()->IS('admin/printing-department') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.printingDepartment')); ?>">
                    <span class="nav-link-icon">
                        <i class="bi bi-check-circle"></i>
                    </span>
                    <span>Printing Department</span>
                </a>
            </li>

            <li>
                <a class="<?php echo e(request()->IS('admin/all-orders') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.allOrders')); ?>">
                    <span class="nav-link-icon">
                        <i class="bi bi-receipt"></i>
                    </span>
                    <span>All Orders</span>
                </a>
            </li>
           
            <?php if(auth()->user()->role_id == 1): ?>

                <li>
                    <a class="<?php echo e(request()->IS('admin/order-history') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.orderHistory')); ?>">
                        <span class="nav-link-icon">
                            <i class="bi bi-wallet2"></i>
                        </span>
                        <span>Order History</span>
                    </a>
                </li>

                <li>
                    <a class="<?php echo e(request()->IS('admin/sales-return') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.salesReturnReport')); ?>">
                        <span class="nav-link-icon">
                            <i class="bi bi-list-ul"></i>
                        </span>
                        <span>Sales Return</span>
                    </a>
                </li>
                <li>
                    <a class="<?php echo e(request()->IS('admin/product') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.product.index')); ?>">
                        <span class="nav-link-icon">
                            <i class="bi bi-app-indicator"></i>
                        </span>
                        <span>Products Big</span>
                    </a>
                </li>

                <li>
                    <a class="<?php echo e(request()->IS('admin/outstanding-amount') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.outstandingAmount')); ?>">
                        <span class="nav-link-icon">
                            <i class="bi bi-truck"></i>
                        </span>
                        <span>Outstanding Amount</span>
                    </a>
                </li>

                <li>
                    <a class="<?php echo e(request()->IS('admin/orderNumber') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.orderNumber.index')); ?>">
                        <span class="nav-link-icon">
                            <i class="bi bi-bar-chart"></i>
                        </span>
                        <span>Order Numbers</span>
                    </a>
                </li>

                <li>
                    <a class="<?php echo e(request()->IS('admin/users') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.users.index')); ?>">
                        <span class="nav-link-icon">
                            <i class="bi bi-people"></i>
                        </span>
                        <span>Users</span>
                    </a>
                </li>

                <li>
                    <a class="<?php echo e(request()->IS('admin/settings') ? 'active' : ''); ?>"  href="<?php echo e(route('admin.settings')); ?>">
                        <span class="nav-link-icon">
                            <i class="bi bi-gear"></i>
                        </span>
                        <span>Settings</span>
                    </a>
                </li>
            <?php endif; ?>
            

          
            <li>
                <a  href="<?php echo e(route('admin.logout')); ?>">
                    <span class="nav-link-icon">
                        <i class="bi bi-person-badge"></i>
                    </span>
                    <span>Logout</span>
                </a>
            </li>
            
           
        </ul>
    </div>
</div>
<!-- ./  menu --><?php /**PATH D:\Projects\Nasa\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>