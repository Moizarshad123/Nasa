
    <!-- Google fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!-- Bootstrap icons -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/icons/bootstrap-icons-1.4.0/bootstrap-icons.min.css')); ?>" type="text/css">
    <!-- Bootstrap Docs -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/bootstrap-docs.css')); ?>" type="text/css">

        <!-- Slick -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/libs/slick/slick.css')); ?>" type="text/css">

    <!-- Main style file -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/app.min.css')); ?>" type="text/css">
    
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/all.min.css')); ?>">


    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/toastr/toastr.min.css')); ?>">
    <link href="<?php echo e(asset('admin/datatables/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
    
    <link rel="stylesheet" href="<?php echo e(asset('admin/dist/css/jqueryDatatable.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <?php /**PATH D:\Projects\Nasa\resources\views/admin/layouts/styles.blade.php ENDPATH**/ ?>