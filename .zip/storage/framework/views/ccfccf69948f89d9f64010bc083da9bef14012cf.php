
<?php $__env->startSection('title', 'Site Setting'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">

        <h3 class="card-title">Site Settings</h3>
        <form class="category-form" method="post" action="<?php echo e(route('admin.settings')); ?>" >
            <?php echo csrf_field(); ?>
            <div class="row">

                <div class="col-md-6">
                    <div class="form-group">
                        <label for="name">Urgent Amount Order (Big)</label>
                        <input type="number" class="form-control" name="urgent_amount_big" id="urgent_amount_big"
                                value="<?php echo e($content->urgent_amount_big ?? ''); ?>" required>
                    </div>
                </div>
                <div class="col-md-6">

                    <div class="form-group">
                        <label for="name">Expose Amount Order (Big)</label>
                        <input type="number" class="form-control" name="expose_amount_big" id="expose_amount_big"
                                value="<?php echo e($content->expose_amount_big ?? ''); ?>" required>
                    </div>
                </div>
                <div class="col-md-6">

                    <div class="form-group">
                        <label for="name">Media Amount Order (Big)</label>
                        <input type="number" class="form-control" name="media_amount_big" id="media_amount_big"
                            value="<?php echo e($content->media_amount_big ?? ''); ?>" required>
                    </div>
                </div>


                <div class="col-md-6">
                    <div class="form-group">
                        <label for="name">Urgent Amount Order (Small)</label>
                        <input type="number" class="form-control" name="urgent_amount_small" id="urgent_amount_small"
                                value="<?php echo e($content->urgent_amount_small ?? ''); ?>" required>
                    </div>
                </div>
                <div class="col-md-6">

                    <div class="form-group">
                        <label for="name">Expose Amount Order (Small)</label>
                        <input type="number" class="form-control" name="expose_amount_small" id="expose_amount_small"
                                value="<?php echo e($content->expose_amount_small ?? ''); ?>" required>
                    </div>
                </div>
                <div class="col-md-6">

                    <div class="form-group">
                        <label for="name">Media Amount Order (Small)</label>
                        <input type="number" class="form-control" name="media_amount_small" id="media_amount_small"
                            value="<?php echo e($content->media_amount_small ?? ''); ?>" required>
                    </div>
                </div>

              

            </div>
            <div class="row" style="margin-top: 10px">
                <div class="col">
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Nasa\resources\views/admin/settings.blade.php ENDPATH**/ ?>