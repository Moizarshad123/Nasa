
<?php $__env->startSection('title', 'View Order'); ?>

<?php $__env->startSection('css'); ?>
<style>
    body{
        font-size: 16px
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <!-- content -->
  <div class="content ">

    <div class="mb-4">
        <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('admin.dashboard')); ?>">
                        <i class="bi bi-globe2 small me-2"></i> Dashboard
                    </a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Order Detail</li>
            </ol>
        </nav>
    </div>

    <div class="row">
        <div class="col-lg-8 col-md-12">
            <div class="card mb-4">
              
                <div class="card-body">

                    <div class="mb-5 d-flex align-items-center justify-content-between">
                        <span>Order No : <a style="font-size:18px" href="javascript:;"><strong><?php echo e($order->order_number ?? ""); ?></strong></a></span>
                        <span class="badge bg-success"><?php echo e($order->status ?? ""); ?></span>
                    </div>
                    <div class="row mb-5 g-4">
                        <div class="col-md-3 col-sm-6">
                            <p class="fw-bold">Order Created at</p>
                           <?php echo e(date('d-m-Y', strtotime($order->creating_date) )); ?>

                        </div>
                        <div class="col-md-3 col-sm-6">
                            <p class="fw-bold">Order Delivered at</p>
                           <?php echo e(date('d-m-Y', strtotime($order->delivery_date) )); ?> <?php echo e(date('h:i A', strtotime($order->delivery_time) )); ?>

                        </div>
                        <div class="col-md-3 col-sm-6">
                            <p class="fw-bold">Customer Name</p>
                            <?php echo e($order->customer_name ?? ""); ?>

                        </div>
                      
                        <div class="col-md-3 col-sm-6">
                            <p class="fw-bold">Contact No</p>
                            <?php echo e($order->phone ?? ""); ?>

                        </div>
                    </div>
                    <div class="row mb-5 g-4">
                        <div class="col-md-3 col-sm-6">
                            <p class="fw-bold">No: of Persons</p>
                           <?php echo e($order->no_of_persons ?? ""); ?>

                        </div>
                        <div class="col-md-3 col-sm-6">
                            <p class="fw-bold">Order Nature</p>
                            <?php echo e($order->order_nature ?? ""); ?>

                        </div>
                        <div class="col-md-3 col-sm-6">
                            <p class="fw-bold">Order Nature Amount</p>
                            <?php echo e($order->order_nature_amount ?? ""); ?>

                        </div>
                      
                        <div class="col-md-3 col-sm-6">
                            <p class="fw-bold">Remarks</p>
                            <?php echo e($order->remarks ?? ""); ?>

                        </div>
                    </div>
                    <div class="row mb-5 g-4">
                        <div class="col-md-3 col-sm-6">
                            <p class="fw-bold">Email Requirement</p>
                           <?php echo e($order->is_email ? "YES" : "NO"); ?>

                        </div>
                        <div class="col-md-3 col-sm-6">
                            <p class="fw-bold">Email Amount</p>
                            <?php echo e($order->email_amount ?? ""); ?>

                        </div>
                        <div class="col-md-3 col-sm-6">
                            <p class="fw-bold">Emails</p>
                            <?php echo e($order->emails ?? ""); ?>

                        </div>
                      
                        <div class="col-md-3 col-sm-6">
                            <p class="fw-bold">Remarks</p>
                            <?php echo e($order->remarks ?? ""); ?>

                        </div>
                    </div>
                    <div class="row mb-5 g-4">
                        <div class="col-md-6 col-sm-6">
                            <p class="fw-bold">Expose/Media/Reorder</p>
                           <?php echo e($order->order_type ?? ""); ?>

                        </div>
                        <div class="col-md-6 col-sm-6">
                            <p class="fw-bold">Expose/Media/Reorder Amount</p>
                            <?php echo e($order->amount ?? ""); ?>

                        </div>
                       
                    </div>
                   
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-md-12 mt-4 mt-lg-0">
            <div class="card mb-4">
                <div class="card-body">
                    <?php if(auth()->user()->role_id != 4): ?>
                        <div class="row">
                            <div class="col">
                                <?php if($order->assign_to ==  auth()->user()->id && $order->status == "Editing Department"): ?>
                                    <a style="float: right" class="btn btn-danger" href="<?php echo e(route('admin.dropJob', $order->id)); ?>">Drop the Job</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    
                    <br>

                    <form action="<?php echo e(route('admin.changeStatus')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                        <div class="row">
                                <?php $firstTwoChars = substr($order->order_number, 0, 2); ?>
                            <div class="col">
                                <select name="status" class="form-control" required>
                                    <option value="">Select Status</option>
                                    <option value="2" <?php echo e($order->status == "Editing Department" ? 'selected' : ""); ?>>Assign To Me</option>
                                    <?php if($firstTwoChars == "Bb"): ?>
                                        <option value="3" <?php echo e($order->status == "Approval" ? 'selected' : ""); ?>>Approval</option>
                                    <?php endif; ?>
                                    <option value="4" <?php echo e($order->status == "Printing Department" ? 'selected' : ""); ?>>Printing Department</option>
                                    <option value="5" <?php echo e($order->status == "Ready" ? 'selected' : ""); ?>>Job Ready</option>
                                    <option value="6" <?php echo e($order->status == "Completed" ? 'selected' : ""); ?>>Completed</option>

                                    <?php if($order->status != "Printing Department" && $order->status != "Ready" && $order->status != "Completed"): ?>
                                        <option value="7" <?php echo e($order->status == "Cancelled" ? 'selected' : ""); ?>>Sales Return</option>
                                    <?php endif; ?>

                                </select>
                            </div>
                            <div class="col">
                                <button type="submit" class="btn btn-sm btn-primary">Update</button>
                            </div>
                        </div>
                    </form>
                    <?php endif; ?>

                    <br><br>
                    <h6 class="card-title mb-4">Price</h6>
                    
                
                    <div class="row justify-content-center">
                        <div class="col-8 text-end">
                            <strong style="float: left">Net Amount:</strong>
                        </div>
                        <div class="col-4">
                            <strong><?php echo e(number_format($order->net_amount) ?? "0.00"); ?></strong>
                        </div>
                        <div class="col-8 text-end">
                            <strong style="float: left">Charged Amount:</strong>
                        </div>
                        <div class="col-4">
                            <strong><?php echo e(number_format($amountCharged) ?? "0.00"); ?></strong>
                        </div>
                        
                        <div class="col-8 text-end">
                            <strong style="float: left">Outstanding Amount:</strong>
                        </div>
                        <div class="col-4">
                            <strong><?php echo e(number_format($order->outstanding_amount) ?? "0.00"); ?></strong>
                        </div>

                    </div>
                </div>
            </div>
            
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            
            <div class="card widget">
                <h5 class="card-header">Order Items</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-custom mb-0">
                            
                            <?php if($firstTwoChars == "Bb"): ?>
                                <thead>
                                    <tr>
                                        <th>Expose</th>
                                        <th>Size</th>
                                        <th>Qty</th>
                                        <th>Print Cost</th>
                                        <th>Studio LPM Total</th>
                                        <th>Media LPM Total</th>
                                        <th>Studio Frame Total</th>
                                        <th>Media Frame Total</th>
                                        <th>Remarks</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(count($detail) > 0): ?>
                                        <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($item->expose ?? ""); ?></td>
                                                <td><?php echo e($item->product->title ?? ""); ?></td>
                                                <td><?php echo e($item->qty ?? ""); ?></td>
                                                <td><?php echo e($item->print_cost ?? ""); ?></td>
                                                <td><?php echo e($item->studio_LPM_total ?? ""); ?></td>
                                                <td><?php echo e($item->media_LPM_total ?? ""); ?></td>
                                                <td><?php echo e($item->studio_frame_total ?? ""); ?></td>
                                                <td><?php echo e($item->media_frame_total ?? ""); ?></td>
                                                <td><?php echo e($item->remarks ?? ""); ?></td>
                                                <td><?php echo e($item->total ?? ""); ?></td>
        
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            <?php else: ?>
                            <thead>
                                <tr>
                                    <th>Expose</th>
                                    <th>Size</th>
                                    <th>Qty</th>
                                    <th>Country</th>
                                    <th>Total</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($detail) > 0): ?>
                                    <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->expose ?? ""); ?></td>
                                            <td><?php echo e($item->product->title ?? ""); ?></td>
                                            <td><?php echo e($item->qty ?? ""); ?></td>
                                            <td><?php echo e($item->country ?? ""); ?></td>
                                            <td><?php echo e($item->total ?? ""); ?></td>
                                            <td><?php echo e($item->remarks ?? ""); ?></td>
    
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
            </div>

            <div class="card widget">
                <h5 class="card-header">Payment History</h5>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-custom mb-0">
                     
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Payment Method</th>
                                    <th>Amount Received By</th>
                                    <th>Amount Received</th>
                                    <th>Amount Charged</th>
                                    <th>Cash Back</th>
                                    <th>Total Amount</th>
                                    <th>Outstanding Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($payments) > 0): ?>
                                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(date('d-m-Y h:i A', strtotime($item->created_at)) ?? ""); ?></td>
                                            <td><?php echo e($item->payment_method ?? ""); ?></td>
                                            <td><?php echo e(isset($item->amountReceivedByUer) ? $item->amountReceivedByUer->name : ""); ?></td>
                                            <td><?php echo e($item->amount_received ?? ""); ?></td>
                                            <td><?php echo e($item->amount_charged ?? ""); ?></td>
                                            <td><?php echo e($item->cash_back ?? ""); ?></td>
                                            <td><?php echo e($order->net_amount); ?></td>
                                            <td><?php echo e($item->outstanding_amount); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                           
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- ./ content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Nasa\resources\views/admin/view_orders.blade.php ENDPATH**/ ?>