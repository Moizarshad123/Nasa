
<?php $__env->startSection('title', 'Site Setting'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- left column -->
                    <div class="col-md-12">
                        <!-- general form elements -->
                        <div class="card card-primary">
                            <div class="card-header">
                                <h3 class="card-title">Site Settings</h3>
                            </div>
                            <form class="category-form" method="post" action="<?php echo e(route('admin.setting')); ?>"
                                    enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="card-body">
                                    <div class="row">

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="name">Urgent Aount</label>
                                                <input type="text" class="form-control" name="urgent_amount" id="urgent_amount"
                                                        value="<?php echo e($content->urgent_amount ?? ''); ?>" required>
                                            </div>

                                            <div class="form-group">
                                                <label for="name">Expose Amount</label>
                                                <input type="text" class="form-control" name="expose_amount" id="expose_amount"
                                                        value="<?php echo e($content->expose_amount ?? ''); ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="name">Media Amount </label>
                                                <input type="text" class="form-control" name="media_amount" id="media_amount"
                                                    value="<?php echo e($content->media_amount ?? ''); ?>" required>
                                            </div>
                                          
                                        </div>


                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- /.card -->
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Nasa\resources\views/admin/setting.blade.php ENDPATH**/ ?>